import FileCardPlaceholder from "./FileCardPlaceholder.js";
export default FileCardPlaceholder;
