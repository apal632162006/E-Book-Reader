import FilesSort from "./FilesSort.js";
export default FilesSort;
