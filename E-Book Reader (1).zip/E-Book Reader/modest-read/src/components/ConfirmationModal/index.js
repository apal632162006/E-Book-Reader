import ConfirmationModal from "./ConfirmationModal.js";
export default ConfirmationModal;
