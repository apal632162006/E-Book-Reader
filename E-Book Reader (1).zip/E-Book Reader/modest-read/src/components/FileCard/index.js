import FileCard from "./FileCard.js";
export default FileCard;
