import ErrorPage from "./ErrorPage.js";
export default ErrorPage;
