import Register from "./Register.js";
export default Register;
