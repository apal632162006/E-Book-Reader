import LandingPage from "./LandingPage.js";
export default LandingPage;
