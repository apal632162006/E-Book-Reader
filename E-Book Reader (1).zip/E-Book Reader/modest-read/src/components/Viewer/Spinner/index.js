import Spinner from "./Spinner.js";
export default Spinner;
