import FileInfo from "./FileInfo.js";
export default FileInfo;
