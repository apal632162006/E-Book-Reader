import Modal from "./Modal.js";
export default Modal;
