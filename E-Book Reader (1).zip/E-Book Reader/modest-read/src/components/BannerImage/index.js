import BannerImage from "./BannerImage.js";
export default BannerImage;
