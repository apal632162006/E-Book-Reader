import iconFull from "assets/icon-text.svg";
import "./banner-image.css";

export default function BannerImage() {
  return <img src={iconFull} className="banner-image" draggable="false" alt=""/>;
}
