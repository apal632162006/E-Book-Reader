# ModestRead

![Project preview](./preview.png)

***

An eBook reader that allows users to upload pdf and epub files and read them in a custom design viewer.

[View project](https://modest-read.fly.dev)
